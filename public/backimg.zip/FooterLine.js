
import styles from '@/app/Styles/footer.module.css'

export default function FooterLine(){

    return (
        <div className={styles.footerline} >
           Copyright© 2023 Spice Money Limited. All right reserved.
        </div>
    )
}